# Colpire i nervi del sistema

**Cyberattacchi, falsi allarmi e strategia della disorganizzazione da Liddell Hart a John Boyd**

Articolo illustrato in italiano, con la citazione iniziale di Cosmo da *I signori della truffa* (*Sneakers*, 1992). Titolo aggiornato, contenuto e figure invariati.

Il progetto contiene `main.tex` (impaginazione), `articolo.tex` (testo), `bibliografia.tex` (fonti), `compila.sh` e sette figure TikZ vettoriali sotto `figure/`; non usa immagini raster.

In Overleaf: importare lo ZIP, selezionare `main.tex` come file principale, scegliere il compilatore **pdfLaTeX**, compilare due volte per risolvere riferimenti e citazioni.
