from pathlib import Path
from html import escape
from embed import experiment,endbits
from lxml import html, etree
import base64, json, re, zipfile
P=Path(__file__).resolve().parent
OUT=P; DIAG=P
root=html.fragment_fromstring((P/'articolo.html').read_text(),create_parent='article')
figures=json.loads((DIAG/'dati.json').read_text())
refs={
 'diffie':('Diffie e Hellman (1976)','https://cr.yp.to/bib/1976/diffie.pdf'),
 'densita':('NIST, teorema dei numeri primi','https://dlmf.nist.gov/27.2'),
 'prime-rsa':('NIST, frequenza dei primi fra i dispari (appendice L)','https://nvlpubs.nist.gov/nistpubs/Legacy/SP/nistspecialpublication800-2.pdf'),
 'origini':('Rivest, Shamir e Adleman, rapporto del MIT (1977)','https://dspace.mit.edu/entities/publication/a2e09fea-6f05-48a5-9ce9-5073dfcde567'),
 'apk':('Android, firma dei pacchetti applicativi','https://source.android.com/docs/security/features/apksigning/v2'),
 'tls':('IETF, TLS 1.3 e verifica delle firme','https://www.rfc-editor.org/rfc/rfc8446.html'),
 'riemann':('Clay Mathematics Institute, memoria del 1859','https://www.claymath.org/collections/riemanns-1859-manuscript/'),
 'zeros':('NIST, zeri della zeta','https://dlmf.nist.gov/25.10'),
 'eulerprod':('NIST, prodotto di Eulero','https://dlmf.nist.gov/25.2'),
 'mermin':('N. D. Mermin, Quantum Computer Science, cap. 3','https://www.cambridge.org/core/books/abs/quantum-computer-science/breaking-rsa-encryption/579FE66F90788A8666334593D3FB40B3'),
 'rsa':('Rivest, Shamir e Adleman, articolo originale','https://people.csail.mit.edu/rivest/pubs/RSA78.pdf'),
 'alpoge':('Levent Alpöge, nota sulla dimostrazione','https://alpo.ge/remark.pdf'),
 'lean':('Lean e Mathlib, comunicato del 21 novembre','https://leanprover-community.github.io/blog/posts/riemann-hypothesis/'),
 'mit':('Andrew Sutherland, documentazione dei controlli','https://math.mit.edu/~drew/grh/'),
  'goldberg':('Leslie Ann Goldberg, Mathematics and AI','https://www.cs.ox.ac.uk/people/leslieann.goldberg/MathsAI.html'),
 'figalli':('Alessio Figalli, intervista al Politecnico di Zurigo','https://ethz.ch/en/news-and-events/eth-news/news/2026/09/no-ai-will-replace-mathematicians-but-i-am-concerned-about-education.html'),
 'ns':('OpenAI, annuncio dell’8 settembre','https://openai.com/index/navier-stokes-solution/'),
 'nspaper':('OpenAI, Finite Time Blowup for Navier–Stokes','https://cdn.openai.com/pdf/32d9f210-8b73-45e0-91bc-82a30aef8a9a/navier-stokes.pdf'),
 'courant':('NYU Courant, il lavoro di Alpöge e Buckmaster','https://cims.nyu.edu/dynamic/news/1528/')}
caps=[f['cap'] for f in figures]
title='Il pessimo rapporto fra l’IA e il pensiero umano'
subtitle='Riemann, RSA e la lettura di una dimostrazione'
def markup(el):
    return (escape(el.text or '')+''.join(etree.tostring(c,encoding='unicode',method='html') for c in el)).strip()
def datatable(data):
    if not data:return ''
    labels,rows=data
    return '<details class="data"><summary>Valori numerici della figura</summary><div class="tablewrap"><table><thead><tr>'+''.join('<th scope="col">'+escape(x)+'</th>' for x in labels)+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+escape(str(v))+'</td>' for v in row)+'</tr>' for row in rows)+'</tbody></table></div></details>'
def imageblock(i,inline):
    f=figures[i-1]; name=f['name']+'.svg'
    src='data:image/svg+xml;base64,'+base64.b64encode((DIAG/'svg'/name).read_bytes()).decode() if inline else 'svg/'+name
    img=f'<img class="tavola" alt="{escape(f["alt"],quote=True)}" src="{src}" loading="lazy" decoding="async">'
    caption=f'<figcaption id="cap-{i}"><b>Figura {i}.</b> {escape(caps[i-1])}</figcaption>'
    heading=f'<div class="fig-head"><span class="fig-name">{escape(f["title"])}</span><button type="button" class="zoom" hidden aria-label="Ingrandisci la figura {i}">Ingrandisci</button></div>'
    controls=experiment(i)
    result=f'<figure id="fig-{i}" aria-labelledby="cap-{i}">{heading}{img}{caption}{controls}{datatable(f["data"])}</figure>'
    return ('<div class="unveil"><details class="comparison" open><summary>Confronta le due serie di resti</summary>'+result+'</details></div>') if i==9 else result
def reflinks(el):
    return ' · '.join(f'<a href="{refs[x][1]}">{escape(refs[x][0])}</a>' for x in el.get('ids').split(','))
def build(inline,atlas=False):
    css=(P/'stile.css').read_text()
    stylesheet='<style>'+css+'</style>' if inline else '<link rel="stylesheet" href="stile.css">'
    name='Atlante delle figure' if atlas else title
    sub=title if atlas else subtitle
    sections=[('riemann','Riemann e i primi'),('rsa','Dai primi a RSA'),('ritorno','La simmetria'),('altre','Approfondimenti')] if atlas else [('esordio','Le nove mattonelle'),('annuncio','I numeri primi'),('documenti','Claude e Navier–Stokes'),('rsa','RSA'),('periodo','Il periodo'),('ritorno','La dimostrazione'),('fonti','Fonti')]
    links=''.join(f'<a href="#{k}">{escape(label)}</a>' for k,label in sections)
    head=('<!doctype html><html lang="it"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
          f'<meta name="description" content="{escape(sub)}"><title>{escape(title+" · "+name if atlas else title)}</title>{stylesheet}</head><body>'
          f'<a class="skip" href="#{sections[0][0]}">Vai al testo</a><main><article><header><h1>{escape(name)}</h1><p class="sub">{escape(sub)}</p>'
          f'<time datetime="2026-11-22">22 novembre 2026</time><nav aria-label="Indice">{links}</nav></header>')
    if atlas:
        parts=[head]; starts={1:sections[0],3:sections[1],10:sections[2],11:sections[3]}
        for i,f in enumerate(figures,1):
            if i in starts:
                if i>1:parts.append('</section>')
                sid,name=starts[i]; parts.append(f'<section id="{sid}"><h2>{name}</h2>')
            parts.append('<p class="invito">'+escape(f["invito"])+'</p>')
            parts.append(imageblock(i,inline))
            parts.append('<div class="lettura"><h3>'+escape(f['rubrica'])+'</h3><p>'+escape(f['lettura'])+'</p></div>')
            if f['src']:
                parts.append('<aside class="refs" aria-label="Fonti">'+' · '.join(f'<a href="{escape(url,quote=True)}">{escape(label)}</a>' for label,url in f['src'])+'</aside>')
        parts.extend(['</section></article></main>',endbits(inline),'</body></html>'])
        return '\n'.join(parts)
    parts=[head]
    for sec in root:
        sid=sec.get("id")
        label=f'aria-labelledby="t-{sid}"' if sec.find('h2') is not None or sec.find('h3') is not None else f'aria-label="{escape(sec.get("data-name"))}"'
        parts.append(f'<section id="{sid}" {label}>')
        for el in sec:
            if el.tag in ('h2','h3'):parts.append(f'<{el.tag} id="t-{sec.get("id")}">{escape(el.text)}</{el.tag}>')
            elif el.tag=='fig':parts.append(imageblock(int(el.get('n')),inline))
            elif el.tag=='refs':parts.append('<div class="fonte"><b>'+escape(el.get('label'))+'</b> '+reflinks(el)+'</div>')
            else:
                import copy
                content=copy.deepcopy(el)
                content.attrib.pop('data-tex',None)
                parts.append(etree.tostring(content,encoding='unicode',method='html').strip())
        parts.append('</section>')
    atlas_href='Le_figure_del_saggio.html' if inline else 'tavole.html'
    parts.append('<footer><a href="'+escape(atlas_href,quote=True)+'">Atlante delle dodici tavole</a></footer>')
    parts.extend(['</article></main>',endbits(inline),'</body></html>'])
    return '\n'.join(parts)
if __name__=='__main__':
    name='Il_pessimo_rapporto_fra_l_IA_e_il_pensiero_umano.html';(OUT/name).write_text(build(True));(P/'index.html').write_text(build(False))
    (OUT/'Le_figure_del_saggio.html').write_text(build(True,True));(P/'tavole.html').write_text(build(False,True))
    with zipfile.ZipFile(OUT/'Diagrammi_TikZ_e_SVG.zip','w',zipfile.ZIP_DEFLATED) as z:
        for name in ['index.html','tavole.html','LEGGIMI.txt','stile.css','esperimenti.js']:
            z.write(P/name,name)
        for directory in ['tikz','svg']:
            for f in sorted((DIAG/directory).iterdir()):z.write(f,f.relative_to(DIAG))
        z.write(DIAG/'Tavole_di_matematica.tex','Tavole_di_matematica.tex')
        for f in sorted((DIAG/'pdf').glob('[0-9]*.pdf')):z.write(f,'pdf/'+f.name)
        z.write(P/'Il_pessimo_rapporto_fra_l_IA_e_il_pensiero_umano.tex','Il_pessimo_rapporto_fra_l_IA_e_il_pensiero_umano.tex')
