from pathlib import Path
import json
P=Path(__file__).resolve().parent
D=json.loads((P/'dati.json').read_text())
start=r"""\documentclass[10pt]{article}
\usepackage[paperwidth=218mm,paperheight=184mm,top=10mm,bottom=9mm,left=15mm,right=15mm]{geometry}
\usepackage[utf8]{inputenc}\usepackage[T1]{fontenc}
\usepackage{mathpazo,graphicx,xcolor,amsmath,hyperref}
\definecolor{vino}{HTML}{842E33}
\definecolor{inchiostro}{HTML}{1E2430}
\definecolor{grigio}{HTML}{697179}
\hypersetup{pdftitle={Il pessimo rapporto fra l’IA e il pensiero umano - Tavole di matematica},pdfauthor={},colorlinks=true,urlcolor=vino,linkcolor=inchiostro,bookmarksopen=true}
\pagestyle{empty}\setlength{\parindent}{0pt}
\raggedbottom\color{inchiostro}
\begin{document}
"""
roman=['I','II','III','IV','V','VI','VII','VIII','IX','X','XI','XII']
def tex(s):
    return s.replace('2 · 23 · 29',r'$2\cdot23\cdot29$').replace('’',"'").replace('≡',r'$\equiv$').replace('√',r'$\sqrt{\vphantom{X}}\,$').replace('&',r'\&')
def context(i):
    if i<3:return 'Riemann e i numeri primi'
    if i<10:return 'Dai primi a RSA'
    if i==10:return 'La lettura della prova'
    return 'Approfondimenti'
out=[start]
for i,f in enumerate(D,1):
    if i>1:out.append(r'\clearpage')
    links=r'\quad $\cdot$ \quad '.join(r'\href{'+url+'}{'+tex(label)+'}' for label,url in f['src'])
    out.append(r'\pdfbookmark[0]{'+tex(f['title'])+'}{tavola'+str(i)+'}')
    out.append(r'{\small\scshape Il pessimo rapporto fra l’IA e il pensiero umano \hfill '+tex(context(i))+r'}\par\vspace{1.7mm}{\color{grigio}\hrule height .4pt}\vspace{3.5mm}')
    out.append(r'{\fontsize{22}{25}\selectfont '+tex(f['title'])+r'\hfill}{\large\color{vino}\itshape '+roman[i-1]+r'}\par\vspace{2.3mm}')
    out.append(r'{\fontsize{10.5}{12.0}\selectfont '+tex(f['invito'])+r'\par}\vspace{1.4mm}')
    out.append(r'\noindent\includegraphics[width=\linewidth]{pdf/'+f['name']+r'.pdf}\par\vspace{2.1mm}')
    out.append(r'{\color{grigio}\hrule height .34pt}\vspace{2.3mm}')
    out.append(r'\noindent\begin{minipage}[t]{.435\linewidth}\raggedright{\bfseries\color{vino} Come si legge}\par\vspace{1.0mm}{\fontsize{10.25}{12.8}\selectfont '+tex(f['cap'])+r'\par}\end{minipage}\hfill')
    out.append(r'\begin{minipage}[t]{.53\linewidth}\raggedright{\bfseries\color{vino} '+tex(f['rubrica'])+r'}\par\vspace{1.0mm}{\fontsize{10.25}{12.8}\selectfont '+tex(f['lettura'])+r'\par}\end{minipage}')
    out.append(r'\par\vfill{\footnotesize\color{grigio} '+(links or 'Esempio di lettura di una dimostrazione')+r'\hfill Tavola '+str(i)+r' di 12\par}')
out.append(r'\end{document}')
(P/'Tavole_di_matematica.tex').write_text('\n'.join(out))

