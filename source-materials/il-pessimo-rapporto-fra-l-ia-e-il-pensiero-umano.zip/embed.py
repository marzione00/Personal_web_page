from pathlib import Path
from html import escape
import json
import mpmath as mp
from sympy import primepi
P=Path(__file__).resolve().parent
prime_json=json.dumps({'count':[int(primepi(n)) for n in range(101)],'est':[0,0]+[float(mp.li(n)-mp.li(2)) for n in range(2,101)]},separators=(',',':'))
specs={
1:('Sposta la soglia del conteggio','Soglia',2,100,100,[(25,'25'),(50,'50'),(100,'100')],'La scala conta i primi. La curva tratteggiata ne stima il numero.'),
5:('Percorri il ciclo dei resti','Esponente',0,20,0,[(0,'Partenza'),(7,'Passo 7'),(10,'Un giro'),(20,'Due giri')],'Il cerchio evidenzia il resto raggiunto. Sul grafico si legge lo stesso valore.'),
9:('Sposta la seconda serie di resti','Spostamento in passi',0,2668,1333,[(1,'Un passo'),(1333,'1333'),(1334,'1334'),(2668,'2668')],'A destra si legge il primo resto, in alto quello successivo allo spostamento. L’anello segue il passo 40.'),
7:('Prova una chiave di decifrazione','Esponente d',1,10,6,[(6,'Prova 6'),(7,'Prova 7'),(8,'Prova 8')],'La linea tratteggiata segna il messaggio 2. L’altezza di ciascun punto è il resto della divisione per 33.'),
10:('Allontana i punti dalla retta','Distanza dalla retta in centesimi',0,45,25,[(0,'Coincidenti'),(10,'Un decimo'),(25,'Un quarto')],'Sposta i dischi blu alla stessa distanza sui due lati. Il rombo indica il punto medio.')}
def experiment(i):
    if i not in specs:return ''
    name,label,lo,hi,val,examples,hint=specs[i]
    buttons=''.join(f'<button type="button" data-value="{v}" aria-pressed="false">{txt}</button>' for v,txt in examples)
    return f'''<details class="experiment" data-figure="{i}" hidden{' open' if i==9 else ''}><summary>{name}</summary><div class="workbench"><p class="hint">{hint}</p><svg class="liveplot" role="img" aria-label="Grafico di {escape(label)}" viewBox="0 0 560 224" xmlns="http://www.w3.org/2000/svg"></svg><label for="slide-{i}">{label}</label><input type="range" id="slide-{i}" min="{lo}" max="{hi}" value="{val}" step="1"><div class="presets">{buttons}</div><output for="slide-{i}" aria-live="polite"></output></div></details>'''
def endbits(inline):
    dialog='<dialog id="ingrandimento" aria-labelledby="zoom-title"><div class="dialog-tools"><h2 id="zoom-title">Figura</h2><button type="button" aria-pressed="false" class="scale">Zoom 2×</button><button type="button" class="exit">Chiudi</button></div><div class="zoom-stage"><img alt=""></div></dialog>'
    js='<script>'+(P/'esperimenti.js').read_text()+'</script>' if inline else '<script src="esperimenti.js"></script>'
    return dialog+'<script type="application/json" id="prime-data">'+prime_json+'</script>'+js
