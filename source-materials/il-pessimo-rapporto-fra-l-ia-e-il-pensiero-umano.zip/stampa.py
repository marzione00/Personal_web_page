from pathlib import Path
from edizione import P,root,title,subtitle,figures,refs
from lxml import etree
import re

preamble=r"""
\documentclass[11pt]{article}
\usepackage[a4paper,top=19mm,bottom=18mm,left=21mm,right=21mm,headsep=4mm,footskip=8mm]{geometry}
\usepackage[T1]{fontenc}\usepackage[utf8]{inputenc}
\usepackage{mathpazo,amsmath,graphicx,xcolor,needspace,fancyhdr,flafter,placeins,hyperref}
\definecolor{nero}{HTML}{20242B}\definecolor{vino}{HTML}{842E33}\definecolor{cenere}{HTML}{56616A}
\hypersetup{pdftitle={Il pessimo rapporto fra l’IA e il pensiero umano},pdfsubject={Riemann, RSA e la lettura di una dimostrazione},pdfauthor={},colorlinks=true,urlcolor=vino,linkcolor=nero,bookmarksopen=true}
\pagestyle{fancy}\fancyhf{}\fancyhead[L]{\footnotesize\itshape\color{cenere}Il pessimo rapporto fra l’IA e il pensiero umano}\fancyfoot[R]{\small\thepage}
\renewcommand{\headrulewidth}{.25pt}\setlength{\headheight}{14pt}
\setlength{\parindent}{1.1em}\setlength{\parskip}{.27em plus .06em minus .02em}
\setlength{\emergencystretch}{1.2em}\frenchspacing\raggedbottom\lefthyphenmin=3\righthyphenmin=3\tolerance=2000
\setlength{\intextsep}{6pt plus 1pt minus 1pt}
\setlength{\textfloatsep}{8pt plus 1pt minus 1pt}
\renewcommand{\topfraction}{.80}\renewcommand{\bottomfraction}{.65}\renewcommand{\textfraction}{.12}
\clubpenalty=8000\widowpenalty=8000
\newcommand{\grande}[2]{\par\Needspace{6\baselineskip}\vspace{2.7mm}\pdfbookmark[0]{#1}{#2}\noindent{\color{nero}\fontsize{19.5}{22}\selectfont #1}\par\nobreak\vspace{1.3mm}}
\newcommand{\piccolo}[2]{\par\Needspace{5\baselineskip}\vspace{2.3mm}\pdfbookmark[1]{#1}{#2}\noindent{\color{nero}\fontsize{16.4}{19}\selectfont #1}\par\nobreak\vspace{.8mm}}
\begin{document}\color{nero}\fontsize{11.25}{14.35}\selectfont
\thispagestyle{empty}
"""
chars={'×':r'\ensuremath{\times}','’':"'",'−':r'\ensuremath{-}','²':r'\textsuperscript{2}','³':r'\textsuperscript{3}','ρ':r'\ensuremath{\rho}','φ':r'\ensuremath{\varphi}','≡':r'\ensuremath{\equiv}','∏':r'\ensuremath{\prod}','&':r'\&','…':r'\ldots{}','½':r'\ensuremath{\tfrac12}'}
def q(s):
    return ''.join(chars.get(c,c) for c in s)
notes={}
for note in root.xpath('.//aside[@class="nota"]'):
    parts=[note.find('b').tail or '']
    for child in list(note)[1:]:
        if child.tag!='a':
            parts.extend([child.text_content(), child.tail or ''])
    notes[note.get('id')]=''.join(parts).strip()
def rich(e):
    content=q(e.text or '')
    for ch in e:
        if ch.get('class')=='nota-rinvio':
            content+=r'\footnote{'+q(notes[ch.find('a').get('href')[1:]])+'}'+q(ch.tail or '')
            continue
        label={'i':'textit','b':'textbf','sup':'textsuperscript','sub':'textsubscript'}[ch.tag]
        content+='\\'+label+'{'+rich(ch)+'}'+q(ch.tail or '')
    return content
w='di-mo-stra-zio-ne di-mo-stra-zio-ni in-tel-li-gen-za ar-ti-fi-cia-le ve-ri-fi-ca-to-ri ve-ri-fi-ca-re e-spo-si-zio-ne e-spo-nen-te e-spo-nen-ti mol-ti-pli-ca-zio-ne mol-ti-pli-ca-zio-ni con-se-guen-za con-di-zio-ne suc-ces-sio-ne suc-ces-si-vo do-man-dan-do ri-fles-sio-ne co-or-di-na-ta co-or-di-na-te o-riz-zon-ta-le pe-ri-o-di-ci-tà de-sti-na-ta-rio as-so-cia-zio-ne as-so-cia-zio-ni'.split()
out=[preamble,'\\hyphenation{'+ ' '.join(w)+'}',r'\noindent{\raggedright\fontsize{28}{31.5}\selectfont '+title.replace(' e il pensiero',r'\\e il pensiero')+r'\par}\vspace{1.4mm}',r'\noindent{\large\itshape '+q(subtitle)+r'}\par\vspace{1.3mm}',r'\noindent{\footnotesize\color{cenere}22 novembre 2026}\par\vspace{3mm}']
for sec in root:
 out.append(r"\FloatBarrier")
 for el in sec:
    if el.tag in ['h2','h3']:
        cmd='grande' if el.tag=='h2' else 'piccolo'
        out.append('\\'+cmd+'{'+q(el.text)+'}{'+sec.get('id')+'}')
    elif el.tag=='p':out.append(rich(el)+'\\par')
    elif el.tag=='blockquote':
        out.append(r'\begin{quote}\itshape '+q(el.text)+r'\end{quote}')
    elif el.tag=='div':out.append(r'\[\displaystyle '+el.get('data-tex')+r'\]')
    elif el.tag=='fig':
        n=int(el.get('n'));f=figures[n-1]
        out.append(r'\par\addvspace{1.3mm}\noindent\begin{minipage}{\linewidth}\centering\includegraphics[width=.82\linewidth]{pdf/'+f['name']+r'.pdf}\par\vspace{.5mm}\raggedright{\fontsize{9.45}{11.5}\selectfont\color{cenere}{\bfseries\color{vino}Figura '+str(n)+'.} '+q(f['cap'])+r'\par}\end{minipage}\par\addvspace{1.8mm}')
    elif el.tag=='refs':
        lst=[r'\href{'+refs[k][1]+'}{'+q(refs[k][0])+'}' for k in el.get('ids').split(',')]
        out.append(r'\par\nobreak\smallskip\noindent{\fontsize{8.45}{10.5}\selectfont\color{cenere}\textit{'+q(el.get('label'))+r'}\quad '+r'\hspace{.45em} $\cdot$ \hspace{.45em}'.join(lst)+r'\par}')
out.append(r'\end{document}')
(P/'Il_pessimo_rapporto_fra_l_IA_e_il_pensiero_umano.tex').write_text('\n'.join(out))

